package com.example.safety_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
