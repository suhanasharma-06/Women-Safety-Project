import 'package:flutter/material.dart';

class SafeZonesScreen extends StatelessWidget {
  const SafeZonesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Nearby Safe Zones',
            style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0.5,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Stack(
        children: [
          // Placeholder for Google Maps API integration for real-time tracking/safe zone locator
          Container(
              color: Colors.grey.shade300,
              child: const Center(
                  child: Text('Live Map View (Police Stations, Hospitals)'))),

          // Filter Bar
          Positioned(
            top: 10,
            left: 10,
            right: 10,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                    onPressed: () {}, child: const Text('Police Station')),
                const SizedBox(width: 10),
                ElevatedButton(
                    onPressed: () {}, child: const Text('Public Area')),
              ],
            ),
          ),

          // Navigation Card (Simulating selected safe zone)
          Positioned(
            bottom: 20,
            left: 20,
            right: 20,
            child: Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('City Police HQ',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('5 min',
                            style: TextStyle(color: Colors.green)),
                        const Text('1.2 km'),
                        ElevatedButton(
                            onPressed: () {},
                            child: const Text('Start Navigation')),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
