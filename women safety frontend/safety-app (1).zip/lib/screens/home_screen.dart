import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text('SafeTrack',
            style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined, color: Colors.black54),
            onPressed: () {
              // Connects to the Settings Screen (Gemini_Generated_Image_lmlandlmlandlmla.jpg)
              Navigator.pushNamed(context, '/settings');
            },
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // Link to Emergency Contacts
            TextButton(
              onPressed: () {
                // Connects to the Contacts Screen (Gemini_Generated_Image_wa7h3uwa7h3uwa7h.jpg)
                Navigator.pushNamed(context, '/contacts');
              },
              child: const Text('Emergency Contacts',
                  style: TextStyle(color: Colors.blue, fontSize: 16)),
            ),
            const SizedBox(height: 40),

            // --- Trigger Toggles (Shake-to-Alert & Voice Command) ---
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                TriggerToggle(label: 'Shake-to-Alert: ON', isActive: true),
                SizedBox(width: 40),
                TriggerToggle(label: 'Voice Command: ON', isActive: true),
              ],
            ),
            const SizedBox(height: 50),

            // --- SOS Button (Core Feature) ---
            SizedBox(
              width: 220,
              height: 220,
              child: ElevatedButton(
                onPressed: () {
                  // Logic: App sends alert + live location, Audio/video recording starts
                  _showSOSConfirmation(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  shape: const CircleBorder(),
                  padding: const EdgeInsets.all(20),
                  elevation: 15,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.warning_amber, size: 55, color: Colors.white),
                    Text(
                      'SOS - Tap for\nInstant Help',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 50),

            // --- Fake Call & Safe Zones Buttons ---
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ActionPillButton(
                  label: 'Fake Incoming Call',
                  icon: Icons.phone_in_talk,
                  color: Colors.blue,
                  onPressed: () {
                    // Logic: Simulates incoming call to escape uncomfortable situation
                  },
                ),
                const SizedBox(width: 20),
                ActionPillButton(
                  label: 'Nearby Safe Zones',
                  icon: Icons.security,
                  color: Colors.grey.shade700,
                  onPressed: () {
                    // Connects to the Safe Zones Screen (Gemini_Generated_Image_90d3tq90d3tq90d3.jpg)
                    Navigator.pushNamed(context, '/safezones');
                  },
                ),
              ],
            ),
            const Spacer(),

            // --- Live Tracking & Auto-Recording Status (Bottom Indicators) ---
            Padding(
              padding: const EdgeInsets.only(bottom: 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: const [
                  StatusIndicator(label: 'Live Tracking: ON', isActive: true),
                  StatusIndicator(
                      label: 'Auto-Recording: READY', isActive: true),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSOSConfirmation(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('SOS Alert Initiated. Contacts are notified!'),
        backgroundColor: Colors.red,
        duration: Duration(seconds: 3),
      ),
    );
  }
}

// --- Reusable Widgets for Home Screen ---

class TriggerToggle extends StatelessWidget {
  final String label;
  final bool isActive;

  const TriggerToggle({super.key, required this.label, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Switch(
          value: isActive,
          onChanged: (bool newValue) {/* Toggling logic */},
          activeColor: Colors.green,
        ),
        Text(label,
            style: const TextStyle(fontSize: 12, color: Colors.black87)),
      ],
    );
  }
}

class ActionPillButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onPressed;

  const ActionPillButton({
    super.key,
    required this.label,
    required this.icon,
    required this.color,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: 18),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
      ),
    );
  }
}

class StatusIndicator extends StatelessWidget {
  final String label;
  final bool isActive;

  const StatusIndicator(
      {super.key, required this.label, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          isActive ? Icons.check_circle : Icons.radio_button_unchecked,
          color: isActive ? Colors.green : Colors.grey,
          size: 16,
        ),
        const SizedBox(width: 4),
        Text(label,
            style: const TextStyle(fontSize: 12, color: Colors.black87)),
      ],
    );
  }
}
