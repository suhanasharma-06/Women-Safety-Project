import 'package:flutter/material.dart';

class SignUpScreen extends StatelessWidget {
  const SignUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // The design style assumes a secure, clean aesthetic.
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              const Icon(Icons.security, color: Colors.blue, size: 60),
              const SizedBox(height: 10),
              const Text(
                'SafeTrack',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              const Text(
                'Secure Registration',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 30),

              // Form Fields
              const TextField(
                  decoration: InputDecoration(
                      labelText: 'Full Name', border: OutlineInputBorder())),
              const SizedBox(height: 15),
              const TextField(
                  decoration: InputDecoration(
                      labelText: 'Passport / Aadhaar Number',
                      border: OutlineInputBorder())),
              const SizedBox(height: 15),
              const TextField(
                decoration: InputDecoration(
                    labelText: 'Create Password',
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.visibility)),
                obscureText: true,
              ),
              const SizedBox(height: 15),
              const TextField(
                decoration: InputDecoration(
                    labelText: 'Emergency Contact 1 (Name & Number)',
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.contacts)),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 15),
              const TextField(
                decoration: InputDecoration(
                    labelText: 'Emergency Contact 2 (Optional)',
                    border: OutlineInputBorder()),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 20),

              Row(
                children: [
                  Checkbox(value: true, onChanged: (bool? v) {}),
                  const Expanded(
                      child: Text(
                          'I agree to the Terms of Service and Privacy Policy.',
                          style: TextStyle(fontSize: 12))),
                ],
              ),
              const SizedBox(height: 20),

              // Register Button
              ElevatedButton(
                onPressed: () {
                  // Navigate to Home Screen after successful registration
                  Navigator.pushReplacementNamed(context, '/home');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8)),
                ),
                child: const Text('Generate Digital ID & Register',
                    style: TextStyle(fontSize: 18)),
              ),
              const SizedBox(height: 10),

              // Login link
              TextButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/login');
                },
                child: const Text('Already have an account? Log In',
                    style: TextStyle(color: Colors.grey)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
