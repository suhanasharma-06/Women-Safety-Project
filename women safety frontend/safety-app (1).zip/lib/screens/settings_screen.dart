import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0.5,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const Text('Emergency Triggers',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          // Shake sensitivity uses a slider
          _buildSettingsSlider('Shake Sensitivity', 0.5),
          // Voice command uses a toggle
          _buildSettingsToggle('Voice Command Activation', true),

          const SizedBox(height: 20),
          const Text('Preventive & Evidence',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          // Auto-recording toggle
          _buildSettingsToggle('Automatic Audio/Video Recording', true),
          _buildSettingsToggle('Evidence Cloud Backup', true),

          const SizedBox(height: 20),
          const Text('Fake Call Customization',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Divider(),
          _buildSettingsField(
              'Caller Name', 'Dr. Smith'), // Customize fake call
          _buildSettingsField('Time Delay (seconds)', '10'),

          const SizedBox(height: 40),
          // Account Section
          ListTile(
            title: const Text('View Digital ID',
                style: TextStyle(color: Colors.blue)),
            trailing: const Icon(Icons.lock),
            onTap: () {},
          ),
          ListTile(
            title: const Text('Log Out', style: TextStyle(color: Colors.red)),
            trailing: const Icon(Icons.exit_to_app),
            onTap: () {
              // Navigate back to Login screen and clear all previous routes
              Navigator.pushNamedAndRemoveUntil(
                  context, '/login', (route) => false);
            },
          ),
        ],
      ),
    );
  }

  // Helper widget for toggles
  Widget _buildSettingsToggle(String title, bool value) {
    return ListTile(
      title: Text(title),
      trailing: Switch(value: value, onChanged: (v) {}),
    );
  }

  // Helper widget for sliders
  Widget _buildSettingsSlider(String title, double value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 16.0, top: 8.0),
          child: Text(title, style: const TextStyle(fontSize: 14)),
        ),
        Slider(
            value: value,
            onChanged: (v) {},
            min: 0.0,
            max: 1.0,
            activeColor: Colors.blue),
      ],
    );
  }

  // Helper widget for text fields
  Widget _buildSettingsField(String title, String initialValue) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        decoration: InputDecoration(
          labelText: title,
          hintText: initialValue,
          border: const OutlineInputBorder(),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        ),
      ),
    );
  }
}
