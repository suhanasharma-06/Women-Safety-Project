import 'package:flutter/material.dart';

class ContactsScreen extends StatelessWidget {
  const ContactsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Emergency Contacts',
            style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0.5,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: ListView(
        // Simulates the list of contacts registered by the user
        children: [
          _buildContactTile('Mom', '022 484 7562', Colors.purple),
          _buildContactTile('Sister', '021 185 8974', Colors.orange),
          _buildContactTile('Friend', '021 481 3567', Colors.red),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {/* Logic to add a new contact */},
        label: const Text('Add New Contact'),
        icon: const Icon(Icons.add),
        backgroundColor: Colors.blue,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }

  ListTile _buildContactTile(String name, String number, Color color) {
    return ListTile(
      leading: CircleAvatar(
          backgroundColor: color,
          child: Text(name[0], style: const TextStyle(color: Colors.white))),
      title: Text(name),
      subtitle: Text(number),
      trailing: IconButton(
          icon: const Icon(Icons.delete_outline, color: Colors.red),
          onPressed: () {}),
    );
  }
}
